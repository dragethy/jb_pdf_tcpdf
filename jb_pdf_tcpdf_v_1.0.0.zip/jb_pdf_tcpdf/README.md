# jb_pdf_tcpdf


##
TODO



Add option to


refer to https://tcpdf.org/examples/example_049/


disable in config file:
<h2 style="color:red;">IMPORTANT:</h2>
<span style="color:red;">If you are using user-generated content, the tcpdf tag can be unsafe.<br />
You can disable this tag by setting to false the <b>K_TCPDF_CALLS_IN_HTML</b> constant on TCPDF configuration file.</span>
<h2>write1DBarcode method in HTML</h2>';

I could use this option instead of code written....

For plugin ui I could simulate this with string search in message for tcpdf.
If found then break, based on field: serializeTCPDFtagParameters yes/no
<tcpdf method="SetDrawColor" params="'.$params.'" />

In reality, you can not disable this, which is not good, so keep my code.
